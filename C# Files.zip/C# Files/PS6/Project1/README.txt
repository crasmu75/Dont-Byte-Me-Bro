﻿Drew McClelland
u0634481
10/02/2014

Can the group of cells within a Spreadsheet be a set? I think you could assume that you would never want two cells with the same name.
Can I use getCellsToRecalculate to get direct and indirect dependents?
Will getCellsToRecalculate ever return duplicates?