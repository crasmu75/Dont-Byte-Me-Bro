﻿Drew McClelland
u0634481
PS6
11/01/14
CS 3500 - F14
*******************************************************************************************************************************************************************************************************

I had so much trouble trying to figure out coded UI tests. I eventually deleted them all because they wouldn't pass. When I recorded the events I would see everything how it shoudl be,
and the assertion part of the test would recognize the values, but when I would run the tests the cells wouldn't  ever be entered. I think it had something to do with the formula changing the value
of the string being displayed in the contents box. I could not figure this out. So I deleted all the tests I recorded and tried to make new ones but it never worked.


******************************************************************************************************************************************************************************************************
Fixed error parsing strings for last two digits of cell row.

TODO: Errors. Formula Errors. DONE



Questions:
Should you auto-append .sprd when saving file? FIXED
Should you auto append what they enter for opening files? How do you do this?
How to make spreadsheet panel resize. FIXED
Threads? DIDN'T DO
What happens on invalid formula? FIXED
What goes in controller?
ping noise? FIXED


Drew McClelland
u0634481
PS4
CS 3500 - F14

Dependent/Dependee relationship?
What to do about setting contents to empty string?
Does GetCellsToRecalculate return duplicates?
How to use dependency graph?
Can I just use GetCellsToRecalculate to return the cells to modify?
Test for abstract spreadsheet.
Test circular exceptions.


Drew McClelland
u0634481
PS5
CS 3500 - F14

Should I store the value in the cell and modify it each time a change is made to the spreadsheet? Or reevaluate every time the getValue function is called?
Should changed be 'true' if the spreadsheet failed to modify due to circular dependency?
Should I import entire spreadsheet from saved file before evaluating each content to determine value? Even though when we change a cell we update value immediately?

